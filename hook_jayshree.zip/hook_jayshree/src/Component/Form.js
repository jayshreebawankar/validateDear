import { useState } from "react";
    
const Form=(props)=>{
    const [update, setUpdate] = useState(0)
    // console.log(props)

    const passing=(event)=>{
        event.preventDefault();
        props.functionRef('Jayshree')   
        console.log(event);
    }   
    return(
        <div className="position">            
            {/* <button style={{height:"20px", width:"100px", justify:'center'}} onClick ={setUpdate(update+1)}>Click me</button>*/}
            <button style={{height:"20px", width:"100px"}} onClick ={passing}>Click me</button>
            <h3>{update}</h3>
        </div>
    )
}
export default Form;