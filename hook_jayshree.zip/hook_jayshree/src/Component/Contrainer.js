const Container =()=>{
    const ContainerFun=()=>{
        console.log('You have presses container button');
    }
    return(
        <div>
            <button onClick={ContainerFun}>Container</button>
       </div>
    )
}
export default Container;