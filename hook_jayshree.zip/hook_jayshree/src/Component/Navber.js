import './Navbar.css'
import {Link} from 'react-router-dom'

const Navbar=()=>{
    return(
    <div>
        <div id="menu"> 
           <nav className="navbar navbar-light" >
              {/* <button><Link to="/"> Home</Link>  </button> */}
              <div className='submenu'><Link to='/'>Form</Link></div>
              <div className='submenu'><Link to='/useEffect'>Container</Link></div>
            </nav>
        </div>   
    </div>
    )
}
export default Navbar;
