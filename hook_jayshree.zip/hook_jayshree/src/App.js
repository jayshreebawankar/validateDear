// D:\Jayshree_Bawankar(MERN)\ReactJS\hooks\node_modules\bootstrap\dist\css\bootstrap.min.css
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css';
import Form from'./Component/Form.js'
import Navbar from './Component/Navber'
import {Routes, Route} from 'react-router-dom'
import Container from './Component/Contrainer.js'

function App() {
  const myFun=(value)=>{
      console.log('i am in myFun',value);
  }
 return (
    <>
    <Navbar>
      <Routes>
        <Route path ='/' element ={<Form funRef = {myFun}/>}/>
        <Route path='/useEffect' element={<Container/>}/>
      </Routes>  
    </Navbar>
    </>
  );
}
export default App;
